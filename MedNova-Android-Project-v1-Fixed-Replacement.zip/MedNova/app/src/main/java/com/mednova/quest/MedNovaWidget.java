package com.mednova.quest;

import android.appwidget.AppWidgetManager;import android.appwidget.AppWidgetProvider;import android.content.*;import android.widget.RemoteViews;import java.util.*;
public class MedNovaWidget extends AppWidgetProvider{
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);} 
 static void update(Context c,AppWidgetManager m,int id){Db db=new Db(c);Db.Day d=db.todayRecord();int xp=db.totalXp();int lv=xp/100+1;RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_mednova);v.setTextViewText(R.id.wLevel,"LVL "+lv);v.setTextViewText(R.id.wXp,xp+" XP • 🔥 "+d.streak);v.setTextViewText(R.id.wHours,String.format(Locale.US,"TODAY %.1f / %.1f h",d.hours,db.target()));v.setProgressBar(R.id.wProgress,100,(int)Math.min(100,100*d.hours/db.target()),false);String next=d.hours<1?"Start a focused study session":d.questions<30?"Solve 30 questions":"Finish one more NEET mission";v.setTextViewText(R.id.wMission,"NEXT → "+next);Intent i=new Intent(c,MainActivity.class);v.setOnClickPendingIntent(R.id.wMission,PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));v.setOnClickPendingIntent(R.id.wName,PendingIntent.getActivity(c,1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));m.updateAppWidget(id,v);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(i.getAction()))onUpdate(c,AppWidgetManager.getInstance(c),i.getIntArrayExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS));}
}
