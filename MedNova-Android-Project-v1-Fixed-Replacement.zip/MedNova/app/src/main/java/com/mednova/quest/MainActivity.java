package com.mednova.quest;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;

public class MainActivity extends android.app.Activity {
    Db db; TextView level,hours,mission,missionHint,questions,accuracy,streak,exam; ProgressBar progress;
    @Override protected void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); db=new Db(this);
        level=findViewById(R.id.tvLevel);hours=findViewById(R.id.tvHours);mission=findViewById(R.id.tvMission);missionHint=findViewById(R.id.tvMissionHint);questions=findViewById(R.id.tvQuestions);accuracy=findViewById(R.id.tvAccuracy);streak=findViewById(R.id.tvStreak);exam=findViewById(R.id.tvExam);progress=findViewById(R.id.progressHours);
        findViewById(R.id.btnLog).setOnClickListener(v->showLog()); findViewById(R.id.btnMission).setOnClickListener(v->showLog()); findViewById(R.id.btnHistory).setOnClickListener(v->startActivity(new Intent(this,HistoryActivity.class))); findViewById(R.id.btnSettings).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        refresh();
    }
    @Override protected void onResume(){super.onResume(); if(db!=null)refresh();}
    void refresh(){Db.Day d=db.todayRecord(); int xp=db.totalXp(); int lv=xp/100+1; level.setText("LEVEL "+lv+" • "+xp+" XP"); hours.setText(String.format(java.util.Locale.US,"%.1f / %.1f h",d.hours,db.target())); progress.setProgress((int)Math.min(100,100*d.hours/db.target())); questions.setText("Q\n"+d.questions); accuracy.setText("ACC\n"+(d.questions==0?"—":String.format(java.util.Locale.US,"%.0f%%",d.acc()))); streak.setText("STREAK\n"+d.streak); String m=d.hours<1?"Start a focused study session":d.questions<30?"Solve 30 questions":"Finish one more NEET mission"; mission.setText(m); missionHint.setText("One clear action at a time. No penalties for a low-energy day."); String ex=db.examDate(); exam.setText(ex==null?"NEET 2027 • Exam date not set":"NEET 2027 • "+ex+" • Countdown shown when valid"); sendBroadcast(new Intent(this,MedNovaWidget.class)); }
    void showLog(){ View v=LayoutInflater.from(this).inflate(R.layout.dialog_log,null); AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Add Study Session").setView(v).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create(); dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(y->{ try{double h=val(v,R.id.etHours,0);int q=(int)val(v,R.id.etQuestions,0);int c=(int)val(v,R.id.etCorrect,0);int d=(int)val(v,R.id.etDpp,0);int yt=(int)val(v,R.id.etYoutube,0); if(c>q)c=q; db.addToday(h,q,c,d,yt); dlg.dismiss(); refresh(); }catch(Exception e){Toast.makeText(this,"Please enter valid numbers",Toast.LENGTH_SHORT).show();}})); dlg.show(); }
    double val(View v,int id,double def){String s=((EditText)v.findViewById(id)).getText().toString().trim();return s.isEmpty()?def:Double.parseDouble(s);}
}
