package com.mednova.quest;

import android.app.Activity; import android.os.Bundle; import android.widget.*; import java.util.*;
public class HistoryActivity extends Activity{
 Db db; @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_history);db=new Db(this);TextView sum=findViewById(R.id.tvSummary),tv=findViewById(R.id.tvHistory);ArrayList<Db.Day> ds=db.all();double h=0;int q=0,xp=0;for(Db.Day d:ds){h+=d.hours;q+=d.questions;xp+=d.xp;}sum.setText(String.format(Locale.US,"Total: %.1f focused hours • %d questions • %d XP • %d tracked days",h,q,xp,ds.size()));StringBuilder s=new StringBuilder();s.append("DATE       HOURS   Q      ACC     DPP   YT   XP\n");s.append("------------------------------------------------\n");for(Db.Day d:ds)s.append(String.format(Locale.US,"%-10s %5.1f %5d %7s %5d %4d %4d\n",d.date,d.hours,d.questions,d.questions==0?"—":String.format(Locale.US,"%.0f%%",d.acc()),d.dpp,d.youtube,d.xp));tv.setText(s.toString());}
}
