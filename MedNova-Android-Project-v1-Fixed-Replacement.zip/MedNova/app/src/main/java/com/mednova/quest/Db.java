package com.mednova.quest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Db extends SQLiteOpenHelper {
    private static final String NAME="mednova.db";
    private static final int VER=1;
    public Db(Context c){ super(c, NAME, null, VER); }
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE daily(date TEXT PRIMARY KEY, hours REAL NOT NULL, questions INTEGER NOT NULL, correct INTEGER NOT NULL, dpp INTEGER NOT NULL, youtube INTEGER NOT NULL, xp INTEGER NOT NULL, missions INTEGER NOT NULL, streak INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE profile(id INTEGER PRIMARY KEY CHECK(id=1), target_hours REAL NOT NULL, exam_date TEXT)");
        ContentValues v=new ContentValues(); v.put("id",1); v.put("target_hours",13.0); v.putNull("exam_date"); db.insert("profile",null,v);
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    public static String today(){ return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    public double target(){ Cursor c=getReadableDatabase().rawQuery("SELECT target_hours FROM profile WHERE id=1",null); try{ return c.moveToFirst()?c.getDouble(0):13.0;} finally{c.close();} }
    public String examDate(){ Cursor c=getReadableDatabase().rawQuery("SELECT exam_date FROM profile WHERE id=1",null); try{ if(!c.moveToFirst()||c.isNull(0)) return null; return c.getString(0);} finally{c.close();} }
    public void saveProfile(double hours,String exam){ ContentValues v=new ContentValues(); v.put("id",1); v.put("target_hours",hours); if(exam==null||exam.trim().isEmpty())v.putNull("exam_date");else v.put("exam_date",exam.trim()); getWritableDatabase().update("profile",v,"id=1",null); }
    public void addToday(double hours,int questions,int correct,int dpp,int yt){
        SQLiteDatabase db=getWritableDatabase(); String d=today();
        Cursor c=db.rawQuery("SELECT hours,questions,correct,dpp,youtube FROM daily WHERE date=?",new String[]{d});
        double oh=0; int oq=0,oc=0,od=0,oy=0; if(c.moveToFirst()){oh=c.getDouble(0);oq=c.getInt(1);oc=c.getInt(2);od=c.getInt(3);oy=c.getInt(4);} c.close();
        hours=Math.max(0,hours); questions=Math.max(0,questions); correct=Math.max(0,Math.min(correct,questions)); dpp=Math.max(0,dpp); yt=Math.max(0,yt);
        double nh=oh+hours; int nq=oq+questions,nc=oc+correct,nd=od+dpp,ny=oy+yt;
        int xp=(int)Math.round(nh*10)+nd*20+(nq/30)*20;
        if(nq>0 && ((double)nc/nq)>=0.90) xp+=20;
        xp+=streakBefore(d)>0?0:0;
        int streak=computeStreakIncludingToday();
        int missions=(nh>0?1:0)+(nd>0?1:0)+(nq>0?1:0);
        ContentValues v=new ContentValues(); v.put("date",d);v.put("hours",nh);v.put("questions",nq);v.put("correct",nc);v.put("dpp",nd);v.put("youtube",ny);v.put("xp",xp);v.put("missions",missions);v.put("streak",streak);
        db.insertWithOnConflict("daily",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    private int streakBefore(String d){return 0;}
    public int computeStreakIncludingToday(){
        Cursor c=getReadableDatabase().rawQuery("SELECT date FROM daily WHERE hours>0 ORDER BY date DESC",null); ArrayList<String> ds=new ArrayList<>(); while(c.moveToNext())ds.add(c.getString(0));c.close();
        if(ds.isEmpty())return 0; String expected=today(); int s=0; SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        for(String x:ds){ if(!x.equals(expected))break; s++; try{Date dt=f.parse(expected); dt=new Date(dt.getTime()-86400000L); expected=f.format(dt);}catch(Exception e){break;} } return s;
    }
    public Day todayRecord(){Cursor c=getReadableDatabase().rawQuery("SELECT date,hours,questions,correct,dpp,youtube,xp,streak FROM daily WHERE date=?",new String[]{today()}); try{ if(!c.moveToFirst()) return new Day(today(),0,0,0,0,0,0,0); return new Day(c.getString(0),c.getDouble(1),c.getInt(2),c.getInt(3),c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7)); }finally{c.close();}}
    public ArrayList<Day> all(){ArrayList<Day> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT date,hours,questions,correct,dpp,youtube,xp,streak FROM daily ORDER BY date DESC",null); while(c.moveToNext())out.add(new Day(c.getString(0),c.getDouble(1),c.getInt(2),c.getInt(3),c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7))); c.close(); return out;}
    public int totalXp(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(xp),0) FROM daily",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    public static class Day { public final String date; public final double hours; public final int questions,correct,dpp,youtube,xp,streak; Day(String d,double h,int q,int c,int dp,int y,int x,int s){date=d;hours=h;questions=q;correct=c;dpp=dp;youtube=y;xp=x;streak=s;} public double acc(){return questions==0?-1:100.0*correct/questions;} }
}
