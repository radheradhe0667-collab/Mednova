# MedNova — NEET Quest Android MVP

A native Android study coach with a hybrid RPG + academic HUD.

## Included
- Offline SQLite database for persistent daily history.
- 13-hour default daily target, editable.
- XP + levels + streaks.
- One-next-mission dashboard.
- Focused hours, questions, accuracy, DPPs, entertainment YouTube minutes.
- History summary and CSV export.
- Home-screen widget with live daily progress.
- Optional NEET 2027 exam date field (not hardcoded).
- No GPS, contacts, camera, or continuous monitoring.

## Build
Open this folder in Android Studio with JDK 21. Let Android Studio sync Gradle and install SDK 35 when prompted, then Build > Build APK(s).

This environment did not contain the Android SDK/Gradle executable, so the APK could not be compiled here. The project is source-complete for local Android Studio build, but it should still be tested on the target phone before daily use.

## Widget
After installation: long-press Android home screen -> Widgets -> MedNova -> place widget.

## Design philosophy
The widget and dashboard intentionally show the next action first. Low-study days do not subtract XP. Entertainment YouTube time is tracked separately and does not create a negative score.
