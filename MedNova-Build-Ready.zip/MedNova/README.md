# MedNova — NEET Quest Android MVP

Native Android study coach with a hybrid RPG + academic HUD.

## Included
- Offline SQLite database for persistent daily history.
- 13-hour default daily target, editable.
- XP + levels + streaks.
- One-next-mission dashboard.
- Focused hours, questions, accuracy, DPPs, entertainment YouTube minutes.
- History summary and CSV export.
- Home-screen widget with live daily progress.
- Optional NEET 2027 exam date field.
- No GPS, contacts, camera, or continuous monitoring.
- GitHub Actions workflow that installs Android SDK 35 and builds the debug APK.

## Build in GitHub Actions
Upload the `MedNova` folder to a GitHub repository. The included `.github/workflows/android.yml` can be run from **Actions → Build MedNova APK → Run workflow**. It installs the required Android SDK packages and Gradle 8.7, then uploads `app-debug.apk` as an artifact.

## Widget
After installation: long-press the Android home screen → Widgets → MedNova → place the widget.

## Design philosophy
The widget and dashboard show the next action first. Low-study days do not subtract XP. Entertainment YouTube time is tracked separately and does not create a negative score.
