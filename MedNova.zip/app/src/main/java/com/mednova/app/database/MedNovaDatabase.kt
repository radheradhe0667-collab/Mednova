package com.mednova.app.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.mednova.app.database.dao.*
import com.mednova.app.models.*

@Database(
    entities = [
        UserStats::class,
        StudySession::class,
        Subject::class,
        Chapter::class,
        QuestionLog::class,
        Dpp::class,
        BacklogItem::class,
        StreakRecord::class,
        DailyHistoryEntry::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MedNovaDatabase : RoomDatabase() {

    abstract fun userStatsDao(): UserStatsDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun subjectDao(): SubjectDao
    abstract fun chapterDao(): ChapterDao
    abstract fun questionLogDao(): QuestionLogDao
    abstract fun dppDao(): DppDao
    abstract fun backlogDao(): BacklogDao
    abstract fun streakDao(): StreakDao
    abstract fun dailyHistoryDao(): DailyHistoryDao

    companion object {
        @Volatile private var INSTANCE: MedNovaDatabase? = null

        fun getInstance(context: Context): MedNovaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MedNovaDatabase::class.java,
                    "mednova.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
