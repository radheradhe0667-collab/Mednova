package com.mednova.app.bridge

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.mednova.app.repository.MedNovaRepository
import com.mednova.app.widget.MedNovaWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * The ONLY JavaScript interface exposed to the WebView. Every method below
 * is a specific, narrow operation -- no generic "eval" or "runQuery" method
 * is exposed, by design (see original bridge spec, section 17).
 *
 * Pattern: each method takes a callbackId, runs on Dispatchers.IO, and posts
 * a JSON result back into the page via window.__bridgeCallback(id, json).
 */
class MedNovaBridge(
    private val context: Context,
    private val webView: WebView,
    private val scope: CoroutineScope,
    private val repo: MedNovaRepository
) {

    private fun postResult(callbackId: String, success: Boolean, data: Any?, error: String? = null) {
        val envelope = JSONObject()
        envelope.put("success", success)
        envelope.put("data", data ?: JSONObject.NULL)
        envelope.put("error", error ?: JSONObject.NULL)
        val json = envelope.toString()
        webView.post {
            webView.evaluateJavascript(
                "window.__bridgeCallback('$callbackId', $json);", null
            )
        }
    }

    private fun run(callbackId: String, block: suspend () -> Any?) {
        scope.launch(Dispatchers.IO) {
            try {
                val result = block()
                postResult(callbackId, true, result)
            } catch (e: Exception) {
                postResult(callbackId, false, null, e.message ?: "unknown_error")
            }
        }
    }

    private fun statsJson(s: com.mednova.app.models.UserStats) = JSONObject().apply {
        put("xp", s.xp)
        put("level", s.level)
        put("xpToNextLevel", s.xpToNextLevel)
        put("currentStreak", s.currentStreak)
        put("longestStreak", s.longestStreak)
        put("dailyTargetMinutes", s.dailyTargetMinutes)
        put("examDateEpochDay", s.examDateEpochDay ?: JSONObject.NULL)
    }

    private fun chapterJson(c: com.mednova.app.models.Chapter) = JSONObject().apply {
        put("id", c.id)
        put("subjectId", c.subjectId)
        put("className", c.className)
        put("name", c.name)
        put("status", c.status)
        put("questionsAttempted", c.questionsAttempted)
        put("questionsCorrect", c.questionsCorrect)
        put("dppCompletedCount", c.dppCompletedCount)
    }

    @JavascriptInterface
    fun getUserStats(callbackId: String) = run(callbackId) {
        val s = repo.getUserStats()
        val questionsSolved = repo.questionsSolvedTotal()
        val accuracy = repo.overallAccuracy()
        val backlogCount = repo.backlogPendingCount()
        val examDays = repo.examCountdownDays()
        statsJson(s).apply {
            put("questionsSolved", questionsSolved)
            put("accuracy", accuracy)
            put("backlogCount", backlogCount)
            put("examDaysRemaining", examDays ?: JSONObject.NULL)
        }
    }

    @JavascriptInterface
    fun getTodayStats(callbackId: String) = run(callbackId) {
        JSONObject(repo.getTodayStats().mapValues { it.value ?: JSONObject.NULL })
    }

    @JavascriptInterface
    fun startStudySession(subject: String, chapter: String, callbackId: String) = run(callbackId) {
        val id = repo.startSession(subject, chapter)
        JSONObject().put("sessionId", id)
    }

    @JavascriptInterface
    fun stopStudySession(sessionId: Double, callbackId: String) = run(callbackId) {
        val stats = repo.stopSession(sessionId.toLong())
        MedNovaWidgetProvider.requestUpdate(context)
        statsJson(stats)
    }

    @JavascriptInterface
    fun addXP(amount: Double, reason: String, callbackId: String) = run(callbackId) {
        val stats = repo.addXp(amount.toInt())
        MedNovaWidgetProvider.requestUpdate(context)
        statsJson(stats)
    }

    @JavascriptInterface
    fun updateMission(missionId: String, status: String, callbackId: String) = run(callbackId) {
        // v1: missions are derived from the next incomplete chapter, so this
        // is a thin hook reserved for a future explicit missions table.
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun getSubjects(callbackId: String) = run(callbackId) {
        val arr = JSONArray()
        repo.getSubjects().forEach { s ->
            arr.put(JSONObject().put("id", s.id).put("name", s.name))
        }
        arr
    }

    @JavascriptInterface
    fun getChapters(subjectId: Double, callbackId: String) = run(callbackId) {
        val arr = JSONArray()
        repo.getChapters(subjectId.toLong()).forEach { arr.put(chapterJson(it)) }
        arr
    }

    @JavascriptInterface
    fun updateChapterStatus(chapterId: Double, status: String, callbackId: String) = run(callbackId) {
        repo.updateChapterStatus(chapterId.toLong(), status)
        MedNovaWidgetProvider.requestUpdate(context)
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun logQuestions(subjectId: Double, chapterId: Double, attempted: Double, correct: Double, callbackId: String) = run(callbackId) {
        repo.logQuestions(subjectId.toLong(), chapterId.toLong(), attempted.toInt(), correct.toInt())
        MedNovaWidgetProvider.requestUpdate(context)
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun logDpp(subjectId: Double, chapterId: Double, total: Double, attempted: Double, correct: Double, callbackId: String) = run(callbackId) {
        repo.logDpp(subjectId.toLong(), chapterId.toLong(), total.toInt(), attempted.toInt(), correct.toInt())
        MedNovaWidgetProvider.requestUpdate(context)
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun getBacklog(callbackId: String) = run(callbackId) {
        val arr = JSONArray()
        repo.getBacklog().forEach { b ->
            arr.put(
                JSONObject()
                    .put("id", b.id)
                    .put("subjectId", b.subjectId)
                    .put("chapterId", b.chapterId ?: JSONObject.NULL)
                    .put("type", b.type)
                    .put("priority", b.priority)
                    .put("estimatedMinutes", b.estimatedMinutes)
                    .put("status", b.status)
            )
        }
        arr
    }

    @JavascriptInterface
    fun addBacklogItem(subjectId: Double, chapterId: Double, type: String, priority: String, estimatedMinutes: Double, callbackId: String) = run(callbackId) {
        repo.addBacklogItem(subjectId.toLong(), chapterId.toLong(), type, priority, estimatedMinutes.toInt())
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun updateBacklogStatus(itemId: Double, status: String, callbackId: String) = run(callbackId) {
        repo.updateBacklogStatus(itemId.toLong(), status)
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun getHistory(range: Double, callbackId: String) = run(callbackId) {
        val arr = JSONArray()
        repo.getHistory(range.toInt()).forEach { h ->
            arr.put(
                JSONObject()
                    .put("dateEpochDay", h.dateEpochDay)
                    .put("studyMinutes", h.studyMinutes)
                    .put("xpEarned", h.xpEarned)
                    .put("questionsAttempted", h.questionsAttempted)
                    .put("accuracy", h.accuracy)
                    .put("dppsCompleted", h.dppsCompleted)
                    .put("streakStatus", h.streakStatus)
            )
        }
        arr
    }

    @JavascriptInterface
    fun setExamDate(epochDay: Double, callbackId: String) = run(callbackId) {
        repo.setExamDate(epochDay.toLong())
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun setDailyTarget(minutes: Double, callbackId: String) = run(callbackId) {
        repo.setDailyTarget(minutes.toInt())
        MedNovaWidgetProvider.requestUpdate(context)
        JSONObject().put("acknowledged", true)
    }

    @JavascriptInterface
    fun updateWidget(callbackId: String) = run(callbackId) {
        MedNovaWidgetProvider.requestUpdate(context)
        JSONObject().put("acknowledged", true)
    }
}
