package com.mednova.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Fired by an AlarmManager alarm (scheduled from MainActivity/bridge, and
 * re-armed by BootReceiver). Simplified v1: a single daily reminder rather
 * than the full notification-preferences system from the original spec.
 */
class MissionReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NotificationHelper.showMissionReminder(
            context,
            "Your next MedNova mission is ready",
            "Open the app to see today's target and keep your streak alive."
        )
    }
}
