package com.mednova.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.mednova.app.MainActivity
import com.mednova.app.MedNovaApplication
import com.mednova.app.R
import kotlinx.coroutines.launch

class MedNovaWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateOne(context, appWidgetManager, id)
        }
    }

    companion object {
        /**
         * Called from anywhere in the app (bridge, session stop, etc.) after
         * any stat that appears on the widget changes. Reads fresh data from
         * Room on a background coroutine, then pushes new RemoteViews to
         * every placed widget instance -- so widget and app can never drift
         * since they share the same repository and database.
         */
        fun requestUpdate(context: Context) {
            val appContext = context.applicationContext
            val manager = AppWidgetManager.getInstance(appContext)
            val ids = manager.getAppWidgetIds(
                android.content.ComponentName(appContext, MedNovaWidgetProvider::class.java)
            )
            if (ids.isEmpty()) return

            val app = appContext as MedNovaApplication
            app.appScope.launch {
                for (id in ids) {
                    updateOne(appContext, manager, id)
                }
            }
        }

        private suspend fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val app = context.applicationContext as MedNovaApplication
            val repo = app.repository
            val stats = repo.getUserStats()
            val today = repo.getTodayStats()
            val minutes = (today["minutesStudied"] as? Int) ?: 0
            val hours = minutes / 60.0
            val targetHours = stats.dailyTargetMinutes / 60.0

            val chapters = repo.getSubjects().firstOrNull { it.name == "Biology" }
                ?.let { repo.getChapters(it.id) }
                ?.firstOrNull { it.status != "COMPLETED" && it.status != "MASTERED" }

            val views = RemoteViews(context.packageName, R.layout.widget_mednova)
            views.setTextViewText(R.id.widgetStreak, "\uD83D\uDD25 ${stats.currentStreak} DAY STREAK")
            views.setTextViewText(R.id.widgetXpLevel, "\u2B50 ${stats.xp} XP   LVL ${stats.level}")
            views.setTextViewText(
                R.id.widgetHours,
                "\u23F1 ${String.format("%.1f", hours)} / ${String.format("%.1f", targetHours)} H"
            )
            views.setTextViewText(
                R.id.widgetMission,
                if (chapters != null) "\uD83C\uDFAF Biology \u2014 ${chapters.name}" else "\uD83C\uDFAF No mission set"
            )

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("deep_link", "dashboard")
            }
            val launchPending = PendingIntent.getActivity(
                context, widgetId, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, launchPending)

            val missionIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("deep_link", "timer")
            }
            val missionPending = PendingIntent.getActivity(
                context, widgetId + 100000, missionIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetStartButton, missionPending)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
