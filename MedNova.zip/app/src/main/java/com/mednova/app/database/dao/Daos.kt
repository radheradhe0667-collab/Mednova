package com.mednova.app.database.dao

import androidx.room.*
import com.mednova.app.models.*

@Dao
interface UserStatsDao {
    @Query("SELECT * FROM user_stats WHERE id = 1 LIMIT 1")
    suspend fun get(): UserStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stats: UserStats)
}

@Dao
interface StudySessionDao {
    @Insert
    suspend fun insert(session: StudySession): Long

    @Update
    suspend fun update(session: StudySession)

    @Query("SELECT * FROM study_sessions WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): StudySession?

    @Query("SELECT * FROM study_sessions WHERE dateEpochDay = :day")
    suspend fun getForDay(day: Long): List<StudySession>

    @Query("SELECT * FROM study_sessions WHERE dateEpochDay BETWEEN :startDay AND :endDay ORDER BY dateEpochDay DESC")
    suspend fun getForRange(startDay: Long, endDay: Long): List<StudySession>

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM study_sessions WHERE dateEpochDay = :day")
    suspend fun totalMinutesForDay(day: Long): Int
}

@Dao
interface SubjectDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(subject: Subject): Long

    @Query("SELECT * FROM subjects ORDER BY id ASC")
    suspend fun getAll(): List<Subject>

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun count(): Int
}

@Dao
interface ChapterDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(chapter: Chapter): Long

    @Update
    suspend fun update(chapter: Chapter)

    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY id ASC")
    suspend fun getForSubject(subjectId: Long): List<Chapter>

    @Query("SELECT * FROM chapters WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Chapter?

    @Query("SELECT COUNT(*) FROM chapters WHERE subjectId = :subjectId")
    suspend fun countForSubject(subjectId: Long): Int
}

@Dao
interface QuestionLogDao {
    @Insert
    suspend fun insert(log: QuestionLog): Long

    @Query("SELECT COALESCE(SUM(attempted),0), COALESCE(SUM(correct),0) FROM question_logs")
    suspend fun totalsRaw(): List<Long>

    @Query("SELECT * FROM question_logs WHERE dateEpochDay BETWEEN :startDay AND :endDay")
    suspend fun getForRange(startDay: Long, endDay: Long): List<QuestionLog>
}

@Dao
interface DppDao {
    @Insert
    suspend fun insert(dpp: Dpp): Long

    @Query("SELECT * FROM dpps WHERE dateEpochDay = :day")
    suspend fun getForDay(day: Long): List<Dpp>

    @Query("SELECT * FROM dpps WHERE dateEpochDay BETWEEN :startDay AND :endDay")
    suspend fun getForRange(startDay: Long, endDay: Long): List<Dpp>
}

@Dao
interface BacklogDao {
    @Insert
    suspend fun insert(item: BacklogItem): Long

    @Update
    suspend fun update(item: BacklogItem)

    @Query("SELECT * FROM backlog_items ORDER BY CASE priority WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END, id ASC")
    suspend fun getAll(): List<BacklogItem>

    @Query("SELECT COUNT(*) FROM backlog_items WHERE status = 'PENDING'")
    suspend fun pendingCount(): Int

    @Query("SELECT * FROM backlog_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): BacklogItem?
}

@Dao
interface StreakDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: StreakRecord)

    @Query("SELECT * FROM streak_records WHERE dateEpochDay = :day LIMIT 1")
    suspend fun getForDay(day: Long): StreakRecord?
}

@Dao
interface DailyHistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: DailyHistoryEntry)

    @Query("SELECT * FROM daily_history WHERE dateEpochDay BETWEEN :startDay AND :endDay ORDER BY dateEpochDay DESC")
    suspend fun getForRange(startDay: Long, endDay: Long): List<DailyHistoryEntry>
}
