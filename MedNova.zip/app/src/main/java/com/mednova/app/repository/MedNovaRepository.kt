package com.mednova.app.repository

import android.content.Context
import com.mednova.app.database.MedNovaDatabase
import com.mednova.app.gamification.StreakEngine
import com.mednova.app.gamification.XpEngine
import com.mednova.app.models.*
import java.time.LocalDate
import java.time.ZoneId

/**
 * Single facade over all DAOs. A deliberate simplification vs. a full
 * per-domain repository split: for a single-developer app this keeps every
 * bridge method's implementation in one place, one file to scan when
 * debugging a data-flow issue.
 */
class MedNovaRepository(context: Context) {

    private val db = MedNovaDatabase.getInstance(context)

    private fun todayEpochDay(): Long = LocalDate.now(ZoneId.systemDefault()).toEpochDay()

    // ---------- Bootstrapping ----------

    suspend fun ensureSeeded() {
        if (db.userStatsDao().get() == null) {
            db.userStatsDao().upsert(UserStats())
        }
        if (db.subjectDao().count() == 0) {
            val physicsId = db.subjectDao().insert(Subject(name = "Physics"))
            val chemistryId = db.subjectDao().insert(Subject(name = "Chemistry"))
            val biologyId = db.subjectDao().insert(Subject(name = "Biology"))

            // Sample seed chapters only (not a full NEET syllabus) so the
            // Subjects screen has real content on first launch.
            val sampleBio = listOf(
                "Breathing and Exchange of Gases" to "12",
                "Body Fluids and Circulation" to "12",
                "Neural Control and Coordination" to "12",
                "Reproduction in Organisms" to "12",
                "Genetics and Evolution" to "12",
                "Diversity in Living World" to "11",
                "Cell: The Unit of Life" to "11"
            )
            sampleBio.forEach { (name, cls) ->
                db.chapterDao().insert(Chapter(subjectId = biologyId, className = cls, name = name))
            }
            val samplePhy = listOf("Laws of Motion" to "11", "Electrostatics" to "12")
            samplePhy.forEach { (name, cls) ->
                db.chapterDao().insert(Chapter(subjectId = physicsId, className = cls, name = name))
            }
            val sampleChem = listOf("Chemical Bonding" to "11", "Electrochemistry" to "12")
            sampleChem.forEach { (name, cls) ->
                db.chapterDao().insert(Chapter(subjectId = chemistryId, className = cls, name = name))
            }
        }
    }

    // ---------- User stats ----------

    suspend fun getUserStats(): UserStats = db.userStatsDao().get() ?: UserStats().also { db.userStatsDao().upsert(it) }

    suspend fun setDailyTarget(minutes: Int) {
        val stats = getUserStats()
        db.userStatsDao().upsert(stats.copy(dailyTargetMinutes = minutes))
    }

    suspend fun setExamDate(epochDay: Long) {
        val stats = getUserStats()
        db.userStatsDao().upsert(stats.copy(examDateEpochDay = epochDay))
    }

    suspend fun addXp(amount: Int): UserStats {
        val stats = getUserStats()
        val updated = XpEngine.applyXp(stats, amount)
        db.userStatsDao().upsert(updated)
        return updated
    }

    // ---------- Study sessions / timer ----------

    suspend fun startSession(subject: String, chapter: String): Long {
        val today = todayEpochDay()
        return db.studySessionDao().insert(
            StudySession(
                subject = subject,
                chapter = chapter,
                dateEpochDay = today,
                startTimeMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun stopSession(sessionId: Long): UserStats {
        val session = db.studySessionDao().getById(sessionId) ?: return getUserStats()
        val endMillis = System.currentTimeMillis()
        val durationMinutes = ((endMillis - session.startTimeMillis) / 60000L).toInt().coerceAtLeast(0)
        val xpEarned = durationMinutes * XpEngine.XP_PER_FOCUSED_MINUTE

        db.studySessionDao().update(
            session.copy(endTimeMillis = endMillis, durationMinutes = durationMinutes, xpEarned = xpEarned)
        )

        val updatedStats = addXp(xpEarned)

        val todayMinutes = db.studySessionDao().totalMinutesForDay(todayEpochDay())
        StreakEngine.recordMinutesForToday(
            todayMinutes, updatedStats.dailyTargetMinutes, db.streakDao(), db.userStatsDao()
        )

        return getUserStats()
    }

    suspend fun getTodayStats(): Map<String, Any?> {
        val today = todayEpochDay()
        val minutes = db.studySessionDao().totalMinutesForDay(today)
        val dpps = db.dppDao().getForDay(today)
        return mapOf(
            "dateEpochDay" to today,
            "minutesStudied" to minutes,
            "dppCompletedToday" to dpps.count { it.status == BacklogStatus.DONE },
            "dppTotalToday" to dpps.size
        )
    }

    // ---------- Subjects / chapters ----------

    suspend fun getSubjects(): List<Subject> = db.subjectDao().getAll()

    suspend fun getChapters(subjectId: Long): List<Chapter> = db.chapterDao().getForSubject(subjectId)

    suspend fun updateChapterStatus(chapterId: Long, status: String) {
        val chapter = db.chapterDao().getById(chapterId) ?: return
        db.chapterDao().update(chapter.copy(status = status))
        if (status == ChapterStatus.COMPLETED) {
            addXp(XpEngine.XP_PER_CHAPTER_COMPLETED)
        }
    }

    // ---------- Questions ----------

    suspend fun logQuestions(subjectId: Long, chapterId: Long, attempted: Int, correct: Int) {
        val incorrect = (attempted - correct).coerceAtLeast(0)
        db.questionLogDao().insert(
            QuestionLog(
                subjectId = subjectId, chapterId = chapterId, attempted = attempted,
                correct = correct, incorrect = incorrect, skipped = 0, dateEpochDay = todayEpochDay()
            )
        )
        val chapter = db.chapterDao().getById(chapterId)
        if (chapter != null) {
            db.chapterDao().update(
                chapter.copy(
                    questionsAttempted = chapter.questionsAttempted + attempted,
                    questionsCorrect = chapter.questionsCorrect + correct
                )
            )
        }
        addXp(correct * XpEngine.XP_PER_CORRECT_ANSWER)
    }

    suspend fun overallAccuracy(): Int {
        val totals = db.questionLogDao().totalsRaw()
        val attempted = totals.getOrElse(0) { 0L }
        val correct = totals.getOrElse(1) { 0L }
        return if (attempted == 0L) 0 else ((correct * 100) / attempted).toInt()
    }

    suspend fun questionsSolvedTotal(): Long = db.questionLogDao().totalsRaw().getOrElse(0) { 0L }

    // ---------- DPP ----------

    suspend fun logDpp(subjectId: Long, chapterId: Long, total: Int, attempted: Int, correct: Int) {
        val accuracy = if (attempted == 0) 0.0 else (correct.toDouble() / attempted.toDouble()) * 100.0
        db.dppDao().insert(
            Dpp(
                subjectId = subjectId, chapterId = chapterId, dateEpochDay = todayEpochDay(),
                totalQuestions = total, attempted = attempted, correct = correct,
                accuracy = accuracy, status = BacklogStatus.DONE
            )
        )
        val chapter = db.chapterDao().getById(chapterId)
        if (chapter != null) {
            db.chapterDao().update(chapter.copy(dppCompletedCount = chapter.dppCompletedCount + 1))
        }
        addXp(XpEngine.XP_PER_DPP_COMPLETED)
    }

    // ---------- Backlog ----------

    suspend fun getBacklog(): List<BacklogItem> = db.backlogDao().getAll()

    suspend fun addBacklogItem(subjectId: Long, chapterId: Long?, type: String, priority: String, estimatedMinutes: Int) {
        db.backlogDao().insert(
            BacklogItem(
                subjectId = subjectId, chapterId = chapterId, type = type,
                priority = priority, estimatedMinutes = estimatedMinutes
            )
        )
    }

    suspend fun updateBacklogStatus(itemId: Long, status: String) {
        val item = db.backlogDao().getById(itemId) ?: return
        db.backlogDao().update(item.copy(status = status))
    }

    suspend fun backlogPendingCount(): Int = db.backlogDao().pendingCount()

    // ---------- History / analytics ----------

    suspend fun getHistory(days: Int): List<DailyHistoryEntry> {
        val today = todayEpochDay()
        val start = today - (days - 1)
        // Roll up on the fly from raw tables rather than requiring a
        // separate nightly job (fine at this data scale for v1).
        val result = mutableListOf<DailyHistoryEntry>()
        for (day in start..today) {
            val minutes = db.studySessionDao().totalMinutesForDay(day)
            val qLogs = db.questionLogDao().getForRange(day, day)
            val attempted = qLogs.sumOf { it.attempted }
            val correct = qLogs.sumOf { it.correct }
            val accuracy = if (attempted == 0) 0.0 else (correct.toDouble() / attempted.toDouble()) * 100.0
            val dpps = db.dppDao().getForDay(day)
            val streakRec = db.streakDao().getForDay(day)
            val sessions = db.studySessionDao().getForDay(day)
            val xpEarned = sessions.sumOf { it.xpEarned }

            result.add(
                DailyHistoryEntry(
                    dateEpochDay = day,
                    studyMinutes = minutes,
                    xpEarned = xpEarned,
                    questionsAttempted = attempted,
                    accuracy = accuracy,
                    dppsCompleted = dpps.count { it.status == BacklogStatus.DONE },
                    missionsCompleted = 0,
                    streakStatus = if (streakRec?.metThreshold == true) "MET" else "MISSED"
                )
            )
        }
        return result.sortedByDescending { it.dateEpochDay }
    }

    suspend fun examCountdownDays(): Long? {
        val stats = getUserStats()
        val exam = stats.examDateEpochDay ?: return null
        return (exam - todayEpochDay()).coerceAtLeast(0)
    }
}
