package com.mednova.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.mednova.app.bridge.MedNovaBridge

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pendingDeepLink: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        val app = application as MedNovaApplication

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
        }

        webView.addJavascriptInterface(
            MedNovaBridge(applicationContext, webView, app.appScope, app.repository),
            "Android"
        )

        pendingDeepLink = intent.getStringExtra("deep_link")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                pendingDeepLink?.let { screen ->
                    view.evaluateJavascript("window.__handleDeepLink && window.__handleDeepLink('$screen');", null)
                    pendingDeepLink = null
                }
            }
        }
        webView.loadUrl("file:///android_asset/web/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        val screen = intent.getStringExtra("deep_link") ?: return
        webView.evaluateJavascript("window.__handleDeepLink && window.__handleDeepLink('$screen');", null)
    }
}
