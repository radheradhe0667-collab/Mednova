package com.mednova.app.gamification

import com.mednova.app.models.UserStats

/**
 * Configurable XP progression. Level N requires (500 + (N-1)*250) XP to clear.
 * Kept as a pure function so it's easy to re-tune without touching call sites.
 */
object XpEngine {

    fun xpRequiredForLevel(level: Int): Int = 500 + (level - 1) * 250

    // Configurable XP sources
    const val XP_PER_FOCUSED_MINUTE = 2
    const val XP_PER_CORRECT_ANSWER = 3
    const val XP_PER_DPP_COMPLETED = 40
    const val XP_PER_CHAPTER_COMPLETED = 100
    const val XP_PER_MISSION_COMPLETED = 60

    /**
     * Applies an XP gain to the given stats, rolling over as many level-ups
     * as the amount warrants, and returns the updated stats.
     */
    fun applyXp(stats: UserStats, amount: Int): UserStats {
        if (amount <= 0) return stats

        var xp = stats.xp + amount
        var level = stats.level
        var xpToNext = stats.xpToNextLevel

        while (xp >= xpToNext) {
            xp -= xpToNext
            level += 1
            xpToNext = xpRequiredForLevel(level)
        }

        return stats.copy(xp = xp, level = level, xpToNextLevel = xpToNext)
    }
}
