package com.mednova.app.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Widgets can go stale across a reboot until something triggers onUpdate.
 * This forces an immediate refresh from the current DB state as soon as the
 * device comes back up.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            MedNovaWidgetProvider.requestUpdate(context)
        }
    }
}
