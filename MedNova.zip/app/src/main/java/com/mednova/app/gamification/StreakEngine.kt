package com.mednova.app.gamification

import com.mednova.app.database.dao.StreakDao
import com.mednova.app.database.dao.UserStatsDao
import com.mednova.app.models.StreakRecord
import java.time.LocalDate
import java.time.ZoneId

/**
 * All streak math is done in epoch-day units derived from the DEVICE's local
 * timezone (never raw UTC millis), so a day boundary always matches what the
 * user actually sees on their clock.
 *
 * Design: rather than incrementing a counter (which is easy to double-count
 * if called more than once in a day, e.g. after every study session), the
 * current streak is *recomputed from scratch* each time by walking backwards
 * through consecutive "threshold met" days in streak_records. This makes the
 * function idempotent and safe to call as often as needed.
 */
object StreakEngine {

    fun todayEpochDay(): Long = LocalDate.now(ZoneId.systemDefault()).toEpochDay()

    /**
     * Call after any change to today's studied minutes (e.g. on session stop).
     * Updates today's streak_records row, then recomputes current/longest
     * streak in user_stats from the full consecutive-day chain.
     */
    suspend fun recordMinutesForToday(
        minutesStudiedToday: Int,
        thresholdMinutes: Int,
        streakDao: StreakDao,
        userStatsDao: UserStatsDao
    ) {
        val today = todayEpochDay()
        val metThreshold = minutesStudiedToday >= thresholdMinutes
        streakDao.upsert(StreakRecord(today, minutesStudiedToday, metThreshold))

        var streak = 0
        var day = today
        while (true) {
            val rec = streakDao.getForDay(day) ?: break
            if (!rec.metThreshold) break
            streak++
            day--
        }

        val stats = userStatsDao.get() ?: return
        val newLongest = maxOf(stats.longestStreak, streak)
        userStatsDao.upsert(stats.copy(currentStreak = streak, longestStreak = newLongest))
    }
}
