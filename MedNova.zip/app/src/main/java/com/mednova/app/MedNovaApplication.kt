package com.mednova.app

import android.app.Application
import com.mednova.app.notifications.NotificationHelper
import com.mednova.app.repository.MedNovaRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MedNovaApplication : Application() {

    val appScope = CoroutineScope(SupervisorJob())
    lateinit var repository: MedNovaRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = MedNovaRepository(this)
        NotificationHelper.ensureChannel(this)
        appScope.launch {
            repository.ensureSeeded()
        }
    }
}
