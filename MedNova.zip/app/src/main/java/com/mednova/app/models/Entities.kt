package com.mednova.app.models

import androidx.room.Entity
import androidx.room.PrimaryKey

object ChapterStatus {
    const val NOT_STARTED = "NOT_STARTED"
    const val LEARNING = "LEARNING"
    const val COMPLETED = "COMPLETED"
    const val REVISION = "REVISION"
    const val MASTERED = "MASTERED"
}

object BacklogPriority {
    const val LOW = "LOW"
    const val MEDIUM = "MEDIUM"
    const val HIGH = "HIGH"
    const val CRITICAL = "CRITICAL"
}

object BacklogType {
    const val LECTURE = "LECTURE"
    const val NOTES = "NOTES"
    const val DPP = "DPP"
    const val QUESTIONS = "QUESTIONS"
    const val REVISION = "REVISION"
}

object BacklogStatus {
    const val PENDING = "PENDING"
    const val DONE = "DONE"
}

@Entity(tableName = "user_stats")
data class UserStats(
    @PrimaryKey val id: Int = 1,
    val xp: Int = 0,
    val level: Int = 1,
    val xpToNextLevel: Int = 500,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val dailyTargetMinutes: Int = 180,
    val examDateEpochDay: Long? = null,
    val notificationsEnabled: Boolean = true
)

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val chapter: String,
    val dateEpochDay: Long,
    val startTimeMillis: Long,
    val endTimeMillis: Long? = null,
    val durationMinutes: Int = 0,
    val xpEarned: Int = 0
)

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(tableName = "chapters")
data class Chapter(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val className: String,
    val name: String,
    val status: String = ChapterStatus.NOT_STARTED,
    val questionsAttempted: Int = 0,
    val questionsCorrect: Int = 0,
    val dppCompletedCount: Int = 0
)

@Entity(tableName = "question_logs")
data class QuestionLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterId: Long,
    val attempted: Int,
    val correct: Int,
    val incorrect: Int,
    val skipped: Int,
    val dateEpochDay: Long
)

@Entity(tableName = "dpps")
data class Dpp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterId: Long,
    val dateEpochDay: Long,
    val totalQuestions: Int,
    val attempted: Int,
    val correct: Int,
    val accuracy: Double,
    val status: String = BacklogStatus.DONE
)

@Entity(tableName = "backlog_items")
data class BacklogItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterId: Long?,
    val type: String,
    val priority: String,
    val estimatedMinutes: Int,
    val status: String = BacklogStatus.PENDING
)

@Entity(tableName = "streak_records")
data class StreakRecord(
    @PrimaryKey val dateEpochDay: Long,
    val minutesStudied: Int,
    val metThreshold: Boolean
)

@Entity(tableName = "daily_history")
data class DailyHistoryEntry(
    @PrimaryKey val dateEpochDay: Long,
    val studyMinutes: Int,
    val xpEarned: Int,
    val questionsAttempted: Int,
    val accuracy: Double,
    val dppsCompleted: Int,
    val missionsCompleted: Int,
    val streakStatus: String
)
