let _subjectsScreenState = { activeSubjectId: null, subjects: [], chapters: [] };

async function renderSubjects() {
    const root = document.getElementById("screen-root");
    root.innerHTML = `<div class="screen active"><div class="placeholder">Loading subjects…</div></div>`;

    const subjects = await Bridge.getSubjects();
    _subjectsScreenState.subjects = subjects;
    if (!_subjectsScreenState.activeSubjectId && subjects.length) {
        _subjectsScreenState.activeSubjectId = subjects[0].id;
    }

    await loadAndRenderSubjectsScreen();
}

async function loadAndRenderSubjectsScreen() {
    const root = document.getElementById("screen-root");
    const { subjects, activeSubjectId } = _subjectsScreenState;
    const chapters = activeSubjectId ? await Bridge.getChapters(activeSubjectId) : [];
    _subjectsScreenState.chapters = chapters;

    const tabs = subjects.map(s => `
        <button class="subject-tab ${s.id === activeSubjectId ? "active" : ""}" data-subject-id="${s.id}">${s.name}</button>
    `).join("");

    const rows = chapters.length ? chapters.map(c => {
        const acc = c.questionsAttempted > 0 ? Math.round((c.questionsCorrect / c.questionsAttempted) * 100) : 0;
        return `
        <div class="chapter-row" data-chapter-id="${c.id}">
            <div>
                <div class="chapter-name">${c.name}</div>
                <div class="chapter-meta">Class ${c.className} · ${c.questionsAttempted} Qs · ${acc}% acc · ${c.dppCompletedCount} DPPs</div>
            </div>
            <select class="status-pill ${c.status}" data-status-select="${c.id}">
                ${["NOT_STARTED", "LEARNING", "COMPLETED", "REVISION", "MASTERED"].map(st =>
                    `<option value="${st}" ${st === c.status ? "selected" : ""}>${st.replace("_", " ")}</option>`
                ).join("")}
            </select>
        </div>`;
    }).join("") : `<div class="placeholder">No chapters yet for this subject.</div>`;

    root.innerHTML = `
        <div class="screen active">
            <div class="subject-tab-row">${tabs}</div>
            <div class="card" style="padding:0;">
                <div style="padding:14px 16px 0;"><div class="card-title">Chapters</div></div>
                ${rows}
            </div>
            <button class="btn-secondary" id="logQuestionsBtn" style="margin-bottom:10px;">Log Questions for a Chapter</button>
            <button class="btn-secondary" id="logDppBtn">Log a DPP</button>
        </div>
    `;

    root.querySelectorAll(".subject-tab").forEach(btn => {
        btn.addEventListener("click", () => {
            _subjectsScreenState.activeSubjectId = Number(btn.dataset.subjectId);
            loadAndRenderSubjectsScreen();
        });
    });

    root.querySelectorAll("[data-status-select]").forEach(sel => {
        sel.addEventListener("change", async (e) => {
            const chapterId = Number(sel.dataset.statusSelect);
            await Bridge.updateChapterStatus(chapterId, sel.value);
            showToast("Chapter status updated");
            loadAndRenderSubjectsScreen();
        });
    });

    document.getElementById("logQuestionsBtn").addEventListener("click", () => promptLogQuestions());
    document.getElementById("logDppBtn").addEventListener("click", () => promptLogDpp());
}

function promptLogQuestions() {
    const { activeSubjectId, chapters } = _subjectsScreenState;
    if (!chapters.length) { showToast("No chapters to log against"); return; }

    openModal({
        title: "Log Questions",
        submitLabel: "Log",
        fields: [
            { name: "chapterId", label: "Chapter", type: "select", options: chapters.map(c => ({ value: c.id, label: c.name })) },
            { name: "attempted", label: "Attempted", value: 10 },
            { name: "correct", label: "Correct", value: 0 }
        ],
        onSubmit: async (v) => {
            if (!v.attempted) return;
            await Bridge.logQuestions(activeSubjectId, Number(v.chapterId), v.attempted, v.correct);
            showToast(`Logged ${v.correct}/${v.attempted} — XP added`);
            loadAndRenderSubjectsScreen();
        }
    });
}

function promptLogDpp() {
    const { activeSubjectId, chapters } = _subjectsScreenState;
    if (!chapters.length) { showToast("No chapters to log against"); return; }

    openModal({
        title: "Log a DPP",
        submitLabel: "Log",
        fields: [
            { name: "chapterId", label: "Chapter", type: "select", options: chapters.map(c => ({ value: c.id, label: c.name })) },
            { name: "total", label: "Total Questions", value: 20 },
            { name: "attempted", label: "Attempted", value: 20 },
            { name: "correct", label: "Correct", value: 0 }
        ],
        onSubmit: async (v) => {
            if (!v.total) return;
            await Bridge.logDpp(activeSubjectId, Number(v.chapterId), v.total, v.attempted, v.correct);
            showToast("DPP logged — XP added");
            loadAndRenderSubjectsScreen();
        }
    });
}
