let _analyticsRange = 7;

async function renderAnalytics() {
    const root = document.getElementById("screen-root");
    root.innerHTML = `<div class="screen active"><div class="placeholder">Loading analytics…</div></div>`;

    const history = await Bridge.getHistory(_analyticsRange);
    const ordered = [...history].reverse(); // oldest -> newest for left-to-right bars

    const maxMinutes = Math.max(1, ...ordered.map(h => h.studyMinutes));
    const bars = ordered.map(h => {
        const pct = Math.round((h.studyMinutes / maxMinutes) * 100);
        const date = epochDayToLabel(h.dateEpochDay);
        return `
            <div class="bar-col">
                <div class="bar-fill" style="height:${Math.max(pct, 3)}%;" title="${h.studyMinutes} min"></div>
                <div class="bar-label">${date}</div>
            </div>`;
    }).join("");

    const totalMinutes = ordered.reduce((sum, h) => sum + h.studyMinutes, 0);
    const totalQuestions = ordered.reduce((sum, h) => sum + h.questionsAttempted, 0);
    const avgAccuracy = ordered.length
        ? Math.round(ordered.reduce((s, h) => s + h.accuracy, 0) / ordered.length)
        : 0;

    const historyRows = history.map(h => `
        <div class="history-row">
            <span>${epochDayToLabel(h.dateEpochDay)}</span>
            <span>${(h.studyMinutes / 60).toFixed(1)}h</span>
            <span>${h.questionsAttempted}Q</span>
            <span>${Math.round(h.accuracy)}%</span>
            <span>${h.streakStatus === "MET" ? "🔥" : "—"}</span>
        </div>
    `).join("");

    root.innerHTML = `
        <div class="screen active">
            <div class="range-row">
                <button class="range-btn ${_analyticsRange === 7 ? "active" : ""}" data-range="7">7 Days</button>
                <button class="range-btn ${_analyticsRange === 30 ? "active" : ""}" data-range="30">30 Days</button>
                <button class="range-btn ${_analyticsRange === 90 ? "active" : ""}" data-range="90">90 Days</button>
            </div>

            <div class="card">
                <div class="card-title">Study Hours</div>
                <div class="bar-chart">${bars || `<div class="placeholder">No data yet</div>`}</div>
            </div>

            <div class="grid-2">
                <div class="stat-tile">
                    <div class="stat-value">${(totalMinutes / 60).toFixed(1)}h</div>
                    <div class="stat-label">Total Hours</div>
                </div>
                <div class="stat-tile">
                    <div class="stat-value">${totalQuestions}</div>
                    <div class="stat-label">Questions</div>
                </div>
                <div class="stat-tile">
                    <div class="stat-value">${avgAccuracy}%</div>
                    <div class="stat-label">Avg Accuracy</div>
                </div>
                <div class="stat-tile">
                    <div class="stat-value">${ordered.filter(h => h.streakStatus === "MET").length}</div>
                    <div class="stat-label">Active Days</div>
                </div>
            </div>

            <div class="card">
                <div class="card-title">Daily History</div>
                ${historyRows || `<div class="placeholder">No history yet</div>`}
            </div>
        </div>
    `;

    root.querySelectorAll(".range-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            _analyticsRange = Number(btn.dataset.range);
            renderAnalytics();
        });
    });
}

function epochDayToLabel(epochDay) {
    // epochDay is days since 1970-01-01 UTC (java.time.LocalDate.toEpochDay());
    // safe to render as a UTC date purely for the short weekday/day label.
    const ms = epochDay * 86400000;
    const d = new Date(ms);
    return d.toLocaleDateString(undefined, { weekday: "short", day: "numeric" });
}
