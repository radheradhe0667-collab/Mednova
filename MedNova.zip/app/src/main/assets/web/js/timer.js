// Timer state lives in JS memory for the ticking display; the source of
// truth for duration/XP is always Kotlin/Room (start/stop are the two bridge
// calls that matter -- pause/resume only affect the on-screen clock so the
// user isn't charged XP for time the app thinks they were paused).
const TimerState = {
    sessionId: null,
    subject: "Biology",
    chapter: "",
    startedAtMs: null,
    accumulatedMs: 0,
    running: false,
    tickHandle: null
};

async function renderTimer(opts) {
    const root = document.getElementById("screen-root");
    if (opts && opts.prefillSubject) TimerState.subject = opts.prefillSubject;
    if (opts && opts.prefillChapter && !TimerState.running) TimerState.chapter = opts.prefillChapter;

    const subjects = await Bridge.getSubjects();

    root.innerHTML = `
        <div class="screen active">
            ${TimerState.running ? "" : `
                <div class="card">
                    <div class="card-title">Session Setup</div>
                    <select class="timer-select" id="timerSubjectSelect">
                        ${subjects.map(s => `<option value="${s.name}" ${s.name === TimerState.subject ? "selected" : ""}>${s.name}</option>`).join("")}
                    </select>
                    <input class="timer-select" id="timerChapterInput" type="text" placeholder="Chapter (e.g. Cell: The Unit of Life)" value="${TimerState.chapter}" />
                </div>
            `}
            <div class="card">
                <div class="timer-display" id="timerDisplay">00:00:00</div>
                <div class="timer-sub" id="timerSub">${TimerState.running ? (TimerState.subject + " — " + TimerState.chapter) : "Ready to start"}</div>
                <div class="btn-row">
                    <button class="btn-primary" id="timerStartPause">${TimerState.running ? "Pause" : "Start"}</button>
                    <button class="btn-secondary btn-danger" id="timerStop" ${TimerState.sessionId ? "" : "disabled"}>Stop</button>
                </div>
            </div>
        </div>
    `;

    updateTimerDisplay();

    document.getElementById("timerStartPause").addEventListener("click", onStartPause);
    const stopBtn = document.getElementById("timerStop");
    if (stopBtn) stopBtn.addEventListener("click", onStop);
}

function updateTimerDisplay() {
    const el = document.getElementById("timerDisplay");
    if (!el) return;
    let ms = TimerState.accumulatedMs;
    if (TimerState.running && TimerState.startedAtMs) {
        ms += (Date.now() - TimerState.startedAtMs);
    }
    const totalSec = Math.floor(ms / 1000);
    const h = String(Math.floor(totalSec / 3600)).padStart(2, "0");
    const m = String(Math.floor((totalSec % 3600) / 60)).padStart(2, "0");
    const s = String(totalSec % 60).padStart(2, "0");
    el.textContent = `${h}:${m}:${s}`;
}

async function onStartPause() {
    if (!TimerState.running) {
        // First start of this session -> create the Room session row.
        if (!TimerState.sessionId) {
            const subjectSel = document.getElementById("timerSubjectSelect");
            const chapterInput = document.getElementById("timerChapterInput");
            TimerState.subject = subjectSel ? subjectSel.value : TimerState.subject;
            TimerState.chapter = chapterInput ? chapterInput.value.trim() : TimerState.chapter;
            if (!TimerState.chapter) { showToast("Enter a chapter first"); return; }

            const res = await Bridge.startStudySession(TimerState.subject, TimerState.chapter);
            TimerState.sessionId = res.sessionId;
        }
        TimerState.running = true;
        TimerState.startedAtMs = Date.now();
        TimerState.tickHandle = setInterval(updateTimerDisplay, 1000);
        renderTimer();
    } else {
        // Pause: fold elapsed time into accumulatedMs, stop the visual ticker.
        // The underlying Room session keeps its original startTime -- so a
        // paused-then-resumed session still logs real wall-clock XP minutes
        // for the whole span. This is a deliberate v1 simplification: true
        // pause-exclusion would need a second native call to split the
        // session, which we can add if you want paused time excluded from XP.
        TimerState.accumulatedMs += Date.now() - TimerState.startedAtMs;
        TimerState.running = false;
        clearInterval(TimerState.tickHandle);
        renderTimer();
    }
}

async function onStop() {
    if (!TimerState.sessionId) return;
    if (TimerState.running) {
        TimerState.accumulatedMs += Date.now() - TimerState.startedAtMs;
        clearInterval(TimerState.tickHandle);
    }
    const stats = await Bridge.stopStudySession(TimerState.sessionId);
    showToast(`Session saved — Lv ${stats.level}, ${stats.xp} XP`);

    TimerState.sessionId = null;
    TimerState.startedAtMs = null;
    TimerState.accumulatedMs = 0;
    TimerState.running = false;
    TimerState.chapter = "";

    renderTimer();
    // Dashboard numbers changed -- if the user goes back to Home it should
    // reflect the new session, not a stale render.
    _dashboardNeedsRefresh = true;
}
