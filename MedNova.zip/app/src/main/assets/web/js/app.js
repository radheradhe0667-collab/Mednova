const SCREENS = ["dashboard", "subjects", "timer", "analytics", "backlog", "focus"];
let _dashboardNeedsRefresh = false;

async function renderScreen(name, opts) {
    const root = document.getElementById("screen-root");

    document.querySelectorAll(".navbtn").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.screen === name || (name === "focus" && btn.dataset.screen === "dashboard"));
    });

    switch (name) {
        case "dashboard":
            await renderDashboard();
            _dashboardNeedsRefresh = false;
            break;
        case "subjects":
            await renderSubjects();
            break;
        case "timer":
            await renderTimer(opts);
            break;
        case "analytics":
            await renderAnalytics();
            break;
        case "backlog":
            await renderBacklog();
            break;
        case "focus":
            root.innerHTML = `<div class="screen active" id="focus-container"></div>`;
            await renderFocusCard(document.getElementById("focus-container"));
            break;
    }
}

function navigateTo(name, opts) {
    if (!SCREENS.includes(name)) return;
    // Never interrupt a running timer session by silently discarding it --
    // just block navigation away from the timer screen while a session is live.
    if (TimerState.running && name !== "timer") {
        showToast("Stop your current session first");
        return;
    }
    renderScreen(name, opts);
    history.pushState({ screen: name }, "", `#${name}`);
}

window.addEventListener("popstate", (e) => {
    const name = (e.state && e.state.screen) || "dashboard";
    renderScreen(name);
});

// Called by MainActivity.kt after a widget tap or notification tap opens the
// app with a deep_link extra (e.g. "dashboard" or "timer").
window.__handleDeepLink = function (screen) {
    navigateTo(screen);
};

document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".navbtn").forEach(btn => {
        btn.addEventListener("click", () => navigateTo(btn.dataset.screen));
    });

    // Refresh dashboard numbers if the user returns to Home after a session
    // finished elsewhere (e.g. via the widget's Start Mission -> Timer -> Stop -> back).
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden && _dashboardNeedsRefresh && location.hash === "#dashboard") {
            renderScreen("dashboard");
        }
    });

    renderScreen("dashboard");
    history.replaceState({ screen: "dashboard" }, "", "#dashboard");
});
