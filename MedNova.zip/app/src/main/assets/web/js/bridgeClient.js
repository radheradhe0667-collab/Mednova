// Real bridge client: wraps window.Android.* (exposed by MedNovaBridge.kt)
// in Promises, matched by callbackId. Falls back to mock data automatically
// when window.Android isn't present (e.g. previewing index.html in a plain
// desktop browser during frontend-only iteration).

const Bridge = (function () {
    const pending = {};
    let counter = 0;

    window.__bridgeCallback = function (callbackId, envelope) {
        const resolver = pending[callbackId];
        if (!resolver) return;
        delete pending[callbackId];
        if (envelope && envelope.success) {
            resolver.resolve(envelope.data);
        } else {
            resolver.reject(new Error((envelope && envelope.error) || "bridge_error"));
        }
    };

    function callNative(methodName, args) {
        return new Promise((resolve, reject) => {
            const callbackId = "cb_" + (counter++) + "_" + Date.now();
            pending[callbackId] = { resolve, reject };
            try {
                window.Android[methodName](...args, callbackId);
            } catch (e) {
                delete pending[callbackId];
                reject(e);
            }
        });
    }

    const isNative = !!window.Android;

    // ---- Mock fallback (used only when there's no native bridge) ----
    const mock = {
        _stats: {
            xp: 2450, level: 8, xpToNextLevel: 3000, currentStreak: 12, longestStreak: 21,
            dailyTargetMinutes: 780, examDateEpochDay: null,
            questionsSolved: 1240, accuracy: 82, backlogCount: 5, examDaysRemaining: 143
        },
        _subjects: [{ id: 1, name: "Physics" }, { id: 2, name: "Chemistry" }, { id: 3, name: "Biology" }],
        _chapters: {
            3: [
                { id: 101, subjectId: 3, className: "12", name: "Breathing and Exchange of Gases", status: "LEARNING", questionsAttempted: 40, questionsCorrect: 30, dppCompletedCount: 2 },
                { id: 102, subjectId: 3, className: "12", name: "Body Fluids and Circulation", status: "NOT_STARTED", questionsAttempted: 0, questionsCorrect: 0, dppCompletedCount: 0 }
            ],
            1: [{ id: 201, subjectId: 1, className: "11", name: "Laws of Motion", status: "COMPLETED", questionsAttempted: 20, questionsCorrect: 15, dppCompletedCount: 1 }],
            2: [{ id: 301, subjectId: 2, className: "11", name: "Chemical Bonding", status: "REVISION", questionsAttempted: 10, questionsCorrect: 9, dppCompletedCount: 1 }]
        },
        _backlog: [
            { id: 1, subjectId: 3, chapterId: 102, type: "DPP", priority: "HIGH", estimatedMinutes: 30, status: "PENDING" },
            { id: 2, subjectId: 1, chapterId: 201, type: "REVISION", priority: "MEDIUM", estimatedMinutes: 45, status: "PENDING" }
        ]
    };

    return {
        isNative,

        getUserStats: () => isNative ? callNative("getUserStats", []) : Promise.resolve(mock._stats),
        getTodayStats: () => isNative ? callNative("getTodayStats", []) : Promise.resolve({ minutesStudied: 510, dppCompletedToday: 2, dppTotalToday: 3 }),

        startStudySession: (subject, chapter) => isNative
            ? callNative("startStudySession", [subject, chapter])
            : Promise.resolve({ sessionId: Date.now() }),

        stopStudySession: (sessionId) => isNative
            ? callNative("stopStudySession", [sessionId])
            : Promise.resolve(mock._stats),

        addXP: (amount, reason) => isNative ? callNative("addXP", [amount, reason]) : Promise.resolve(mock._stats),

        getSubjects: () => isNative ? callNative("getSubjects", []) : Promise.resolve(mock._subjects),

        getChapters: (subjectId) => isNative
            ? callNative("getChapters", [subjectId])
            : Promise.resolve(mock._chapters[subjectId] || []),

        updateChapterStatus: (chapterId, status) => isNative
            ? callNative("updateChapterStatus", [chapterId, status])
            : Promise.resolve({ acknowledged: true }),

        logQuestions: (subjectId, chapterId, attempted, correct) => isNative
            ? callNative("logQuestions", [subjectId, chapterId, attempted, correct])
            : Promise.resolve({ acknowledged: true }),

        logDpp: (subjectId, chapterId, total, attempted, correct) => isNative
            ? callNative("logDpp", [subjectId, chapterId, total, attempted, correct])
            : Promise.resolve({ acknowledged: true }),

        getBacklog: () => isNative ? callNative("getBacklog", []) : Promise.resolve(mock._backlog),

        addBacklogItem: (subjectId, chapterId, type, priority, estimatedMinutes) => isNative
            ? callNative("addBacklogItem", [subjectId, chapterId, type, priority, estimatedMinutes])
            : Promise.resolve({ acknowledged: true }),

        updateBacklogStatus: (itemId, status) => isNative
            ? callNative("updateBacklogStatus", [itemId, status])
            : Promise.resolve({ acknowledged: true }),

        getHistory: (range) => isNative ? callNative("getHistory", [range]) : Promise.resolve([]),

        setExamDate: (epochDay) => isNative ? callNative("setExamDate", [epochDay]) : Promise.resolve({ acknowledged: true }),
        setDailyTarget: (minutes) => isNative ? callNative("setDailyTarget", [minutes]) : Promise.resolve({ acknowledged: true }),
        updateWidget: () => isNative ? callNative("updateWidget", []) : Promise.resolve({ acknowledged: true })
    };
})();
