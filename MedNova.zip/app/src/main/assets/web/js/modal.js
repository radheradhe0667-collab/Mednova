// Lightweight in-page modal, used instead of window.prompt()/window.alert(),
// since a bare Android WebView (no WebChromeClient) does not show native JS
// dialogs at all -- they would silently no-op on-device.

function openModal({ title, fields, submitLabel = "Save", onSubmit }) {
    const existing = document.getElementById("mn-modal-overlay");
    if (existing) existing.remove();

    const overlay = document.createElement("div");
    overlay.id = "mn-modal-overlay";
    overlay.style.cssText = `
        position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:1000;
        display:flex; align-items:flex-end; justify-content:center;
    `;

    const fieldsHtml = fields.map(f => {
        if (f.type === "select") {
            return `
                <label style="display:block;font-size:12px;color:var(--text-dim);margin:10px 0 4px;">${f.label}</label>
                <select class="timer-select" data-field="${f.name}">
                    ${f.options.map(o => `<option value="${o.value}">${o.label}</option>`).join("")}
                </select>`;
        }
        return `
            <label style="display:block;font-size:12px;color:var(--text-dim);margin:10px 0 4px;">${f.label}</label>
            <input class="timer-select" type="number" inputmode="numeric" data-field="${f.name}" value="${f.value || ""}" placeholder="${f.placeholder || ""}" />`;
    }).join("");

    overlay.innerHTML = `
        <div style="background:var(--surface);border-top-left-radius:20px;border-top-right-radius:20px;
                    width:100%;max-width:480px;padding:20px;border:1px solid var(--border);border-bottom:none;">
            <div style="font-size:16px;font-weight:700;margin-bottom:4px;">${title}</div>
            ${fieldsHtml}
            <div class="btn-row" style="margin-top:18px;">
                <button class="btn-secondary" id="mn-modal-cancel">Cancel</button>
                <button class="btn-primary" id="mn-modal-submit">${submitLabel}</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    overlay.querySelector("#mn-modal-cancel").addEventListener("click", () => overlay.remove());
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector("#mn-modal-submit").addEventListener("click", () => {
        const values = {};
        fields.forEach(f => {
            const el = overlay.querySelector(`[data-field="${f.name}"]`);
            values[f.name] = f.type === "select" ? el.value : Number(el.value || 0);
        });
        overlay.remove();
        onSubmit(values);
    });
}

function showToast(message) {
    let toast = document.getElementById("toast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "toast";
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
