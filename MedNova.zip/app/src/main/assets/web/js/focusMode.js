// ADHD-friendly Focus Mode: show exactly one task. Rescue Mode kicks in when
// today's studied minutes are far behind the daily target, offering one
// small achievable step instead of the full remaining plan.

async function renderFocusCard(containerEl) {
    const [stats, today, subjects] = await Promise.all([
        Bridge.getUserStats(), Bridge.getTodayStats(), Bridge.getSubjects()
    ]);

    const minutesLeft = Math.max(0, stats.dailyTargetMinutes - (today.minutesStudied || 0));
    const behindThreshold = stats.dailyTargetMinutes * 0.5;
    const isRescue = (today.minutesStudied || 0) < behindThreshold && minutesLeft > 60;

    let taskLabel = "Study — pick a chapter";
    let taskMinutes = isRescue ? 15 : 45;

    const bio = subjects.find(s => s.name === "Biology");
    if (bio) {
        const chapters = await Bridge.getChapters(bio.id);
        const next = chapters.find(c => c.status !== "COMPLETED" && c.status !== "MASTERED");
        if (next) taskLabel = `Biology — ${next.name}`;
    }

    containerEl.innerHTML = `
        ${isRescue ? `<div class="rescue-banner">Behind today? Don't restart the whole plan — just do one small thing.</div>` : ""}
        <div class="focus-wrap">
            <div class="focus-label">${isRescue ? "Rescue Mode" : "Current Mission"}</div>
            <div class="focus-task">${taskLabel}</div>
            <div class="focus-minutes">${taskMinutes} minutes</div>
            <button class="btn-primary" id="focusStartBtn" style="max-width:220px;margin:0 auto;">START</button>
        </div>
    `;

    document.getElementById("focusStartBtn").addEventListener("click", () => {
        navigateTo("timer", { prefillSubject: "Biology", prefillChapter: taskLabel.replace("Biology — ", "") });
    });
}
