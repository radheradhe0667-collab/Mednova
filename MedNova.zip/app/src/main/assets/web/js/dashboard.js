async function renderDashboard() {
    const root = document.getElementById("screen-root");
    root.innerHTML = `<div class="screen active"><div class="placeholder">Loading dashboard…</div></div>`;

    const [stats, today, subjects] = await Promise.all([
        Bridge.getUserStats(),
        Bridge.getTodayStats(),
        Bridge.getSubjects()
    ]);

    // Find the next incomplete Biology chapter as "next mission" (v1 heuristic:
    // missions are derived from chapter status rather than a separate table).
    let mission = { subject: "Biology", chapter: "Add chapters to get started", minutes: 30, subjectId: null, chapterId: null };
    const bio = subjects.find(s => s.name === "Biology");
    if (bio) {
        const chapters = await Bridge.getChapters(bio.id);
        const next = chapters.find(c => c.status !== "COMPLETED" && c.status !== "MASTERED");
        if (next) {
            mission = { subject: "Biology", chapter: next.name, minutes: 45, subjectId: bio.id, chapterId: next.id };
        }
    }

    const xpPct = Math.min(100, Math.round((stats.xp / stats.xpToNextLevel) * 100));
    const todayMinutes = today.minutesStudied || 0;
    const todayPct = Math.min(100, Math.round((todayMinutes / stats.dailyTargetMinutes) * 100));
    const todayHrs = (todayMinutes / 60).toFixed(1);
    const targetHrs = (stats.dailyTargetMinutes / 60).toFixed(1);
    const examText = stats.examDaysRemaining != null ? `${stats.examDaysRemaining} days to NEET` : "Set your NEET date";

    document.getElementById("examCountdown").textContent = examText;

    root.innerHTML = `
        <div class="screen active" id="screen-dashboard">

            <div class="card mission-card">
                <div class="mission-label">Next Mission</div>
                <div class="mission-title">${mission.subject} — ${mission.chapter}</div>
                <div class="mission-meta">${mission.minutes} min</div>
                <button class="btn-primary" id="startMissionBtn">Start Mission</button>
            </div>

            <button class="btn-secondary" id="focusModeBtn" style="margin-bottom:14px;">🎯 Focus Mode (one task only)</button>

            <div class="card">
                <div class="card-title">Level & XP</div>
                <div class="level-row">
                    <div class="level-badge">Lv ${stats.level}</div>
                    <div class="xp-text">${stats.xp} / ${stats.xpToNextLevel} XP</div>
                </div>
                <div class="progress-track"><div class="progress-fill xp" style="width:${xpPct}%"></div></div>
            </div>

            <div class="card">
                <div class="card-title">Streak</div>
                <div class="streak-row">
                    <div class="streak-flame">🔥</div>
                    <div>
                        <div class="streak-number">${stats.currentStreak} days</div>
                        <div class="streak-sub">Longest: ${stats.longestStreak} days</div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-title">Today's Progress</div>
                <div class="level-row">
                    <div class="xp-text">${todayHrs}h / ${targetHrs}h</div>
                    <div class="xp-text">${todayPct}%</div>
                </div>
                <div class="progress-track"><div class="progress-fill success" style="width:${todayPct}%"></div></div>
            </div>

            <div class="grid-2">
                <div class="stat-tile">
                    <div class="stat-value">${stats.questionsSolved}</div>
                    <div class="stat-label">Questions Solved</div>
                </div>
                <div class="stat-tile">
                    <div class="stat-value">${stats.accuracy}%</div>
                    <div class="stat-label">Accuracy</div>
                </div>
                <div class="stat-tile">
                    <div class="stat-value">${today.dppCompletedToday}/${today.dppTotalToday}</div>
                    <div class="stat-label">DPP Today</div>
                </div>
                <div class="stat-tile">
                    <div class="stat-value">${stats.backlogCount}</div>
                    <div class="stat-label">Backlog Items</div>
                </div>
            </div>

        </div>
    `;

    document.getElementById("startMissionBtn").addEventListener("click", () => {
        navigateTo("timer", { prefillSubject: mission.subject, prefillChapter: mission.chapter });
    });
    document.getElementById("focusModeBtn").addEventListener("click", () => {
        navigateTo("focus");
    });
}
