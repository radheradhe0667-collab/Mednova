async function renderBacklog() {
    const root = document.getElementById("screen-root");
    root.innerHTML = `<div class="screen active"><div class="placeholder">Loading backlog…</div></div>`;

    const [items, subjects] = await Promise.all([Bridge.getBacklog(), Bridge.getSubjects()]);
    const subjectName = (id) => (subjects.find(s => s.id === id) || {}).name || "—";

    const rows = items.filter(i => i.status === "PENDING").map(i => `
        <div class="backlog-row" data-item-id="${i.id}">
            <div>
                <span class="priority-dot ${i.priority}"></span>
                <span class="chapter-name">${i.type} · ${subjectName(i.subjectId)}</span>
                <div class="chapter-meta">${i.estimatedMinutes} min · ${i.priority}</div>
            </div>
            <button class="checkbtn" data-done="${i.id}">✓</button>
        </div>
    `).join("");

    const doneCount = items.length - items.filter(i => i.status === "PENDING").length;

    root.innerHTML = `
        <div class="screen active">
            <div class="card">
                <div class="card-title">Pending (${items.filter(i => i.status === "PENDING").length}) · Done (${doneCount})</div>
                ${rows || `<div class="placeholder">Backlog is clear 🎉</div>`}
            </div>
            <button class="btn-secondary" id="addBacklogBtn">Add Backlog Item</button>
        </div>
    `;

    root.querySelectorAll("[data-done]").forEach(btn => {
        btn.addEventListener("click", async () => {
            await Bridge.updateBacklogStatus(Number(btn.dataset.done), "DONE");
            showToast("Marked done");
            renderBacklog();
        });
    });

    document.getElementById("addBacklogBtn").addEventListener("click", async () => {
        const chapters = [];
        for (const s of subjects) {
            const cs = await Bridge.getChapters(s.id);
            cs.forEach(c => chapters.push({ ...c, subjectName: s.name }));
        }
        if (!chapters.length) { showToast("Add chapters first"); return; }

        openModal({
            title: "Add Backlog Item",
            submitLabel: "Add",
            fields: [
                { name: "chapterId", label: "Chapter", type: "select", options: chapters.map(c => ({ value: `${c.subjectId}:${c.id}`, label: `${c.subjectName} — ${c.name}` })) },
                { name: "type", label: "Type", type: "select", options: ["LECTURE", "NOTES", "DPP", "QUESTIONS", "REVISION"].map(t => ({ value: t, label: t })) },
                { name: "priority", label: "Priority", type: "select", options: ["LOW", "MEDIUM", "HIGH", "CRITICAL"].map(p => ({ value: p, label: p })) },
                { name: "estimatedMinutes", label: "Estimated Minutes", value: 30 }
            ],
            onSubmit: async (v) => {
                const [subjectId, chapterId] = String(v.chapterId).split(":").map(Number);
                await Bridge.addBacklogItem(subjectId, chapterId, v.type, v.priority, v.estimatedMinutes);
                showToast("Added to backlog");
                renderBacklog();
            }
        });
    });
}
