# MedNova

NEET preparation + study productivity + gamification app.
Hybrid architecture: Android WebView (HTML/CSS/JS UI) + Kotlin native layer
(Room persistence, JS↔Kotlin bridge, real AppWidget, notifications).

## How to open and build

**Option A — GitHub Actions (recommended, no local Android Studio needed):**
Push this project to a GitHub repo. The included `.github/workflows/android.yml`
installs the Android SDK and Gradle 8.7 and runs `gradle assembleDebug`
automatically on every push (or manually via the "Run workflow" button under
Actions). The compiled `app-debug.apk` is attached as a downloadable
workflow artifact named `MedNova-debug`. This is the fastest way to get an
actual compiled, installable APK and to catch any build errors, since I
can't run an Android SDK/Gradle toolchain in the environment I built this in.

**Option B — Android Studio locally:**
1. Open this folder (`MedNova/`) directly in Android Studio (Hedgehog or newer)
   — "Open an existing project", point at the folder containing `settings.gradle.kts`.
2. Let Gradle sync. It will download Room, WorkManager, and coroutines on first sync.
3. Run on an emulator or device, **API 26+**.
4. To test the widget: long-press the home screen → Widgets → MedNova → drag it on.

## What's implemented

- WebView shell with JS↔Kotlin bridge (`MedNovaBridge.kt`, `bridgeClient.js`) —
  Promise-based on the JS side, callback-envelope based on the Kotlin side.
- Room database with 9 tables: user stats, study sessions, subjects, chapters,
  question logs, DPPs, backlog items, streak records, daily history.
- XP + leveling (`XpEngine.kt`) and timezone-safe streak tracking
  (`StreakEngine.kt`, recomputed from history each time — never an
  incrementing counter, so it can't double-count).
- Real focus timer (start/pause/resume/stop) that persists sessions and
  awards XP/streak credit on stop.
- Subjects → Chapters with status (Not Started/Learning/Completed/Revision/
  Mastered), question logging, DPP logging — all update chapter stats and
  award XP.
- Backlog manager (type/priority/estimated time, mark done).
- Analytics screen with CSS-only bar chart (no external chart library, to
  keep the app fully offline) and a daily history list, 7/30/90-day ranges.
- ADHD-friendly Focus Mode (single task) and Rescue Mode (small task, shown
  automatically when today's minutes are well behind target).
- **Real Android home-screen AppWidget** — `MedNovaWidgetProvider.kt` reads
  the same Room database as the app (no duplicate storage), refreshes
  whenever XP/streak/session data changes, survives reboot via
  `BootReceiver.kt`, and tapping it deep-links into the app.
- Basic native notification (`NotificationHelper.kt` / `MissionReminderReceiver.kt`).
- In-page modal (`modal.js`) for data entry — deliberately not
  `window.prompt()`, which silently does nothing in a bare WebView without a
  `WebChromeClient`.

## Known simplifications vs. the original spec (flagging these explicitly)

- **One consolidated `MedNovaRepository`** instead of seven separate
  per-domain repository classes — easier to trace a bug end-to-end in a
  single file at this project size.
- **Widget refresh is a direct `AppWidgetManager` push** from a coroutine,
  not routed through `WorkManager`. Simpler and just as reliable for this
  use case; can be swapped to WorkManager later if you want update
  durability guarantees across process death mid-write.
- **Notifications are a single manual reminder type**, not a full
  preferences system — there's a channel and a working notification, but no
  in-app UI yet to schedule/configure recurring reminders or opt out.
- **No exam-date / daily-target settings screen yet** — `setExamDate` and
  `setDailyTarget` exist on the bridge and work, but nothing in the UI calls
  them yet, so the countdown will show "Set your NEET date" until wired up.
- **Seed data is a small sample**, not the full NEET syllabus — 3 subjects
  and a handful of chapters (weighted toward Biology) so the Subjects screen
  has real content on first launch. Add more chapters via a future
  "add chapter" UI, or ask me to seed more directly into `ensureSeeded()`.
- **Pause doesn't exclude time from XP** — pausing stops the visual clock,
  but the underlying session's start→end span (used for XP) still spans the
  paused time. Flagged in `timer.js` with a comment; happy to add a proper
  split-session pause if you want paused time excluded.
- **Missions are derived**, not a stored table — "next mission" is just "the
  first incomplete Biology chapter." `updateMission()` exists on the bridge
  as a stub for when a dedicated missions table is added.

## Untested build risk

I don't have an Android SDK/Gradle toolchain in the environment I built this
in, so **nothing here has actually been compiled**. It's internally
consistent (matching bridge method names/signatures on both sides, matching
DAO/entity fields, matching resource IDs between layouts and Kotlin) as far
as manual review can confirm, but the first real build is the real test. If
it fails, send me the exact file/line/error from Android Studio's Build
output and I'll fix it directly rather than guessing.
