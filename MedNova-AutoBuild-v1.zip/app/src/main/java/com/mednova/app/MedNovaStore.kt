package com.mednova.app

import android.content.Context
import java.time.LocalDate

object MedNovaStore {
    private const val PREF = "mednova"
    private const val XP = "xp"
    private const val HOURS = "hours"
    private const val STREAK = "streak"
    private const val ACTIVE_DATE = "active_date"
    private const val MISSION = "mission"

    private fun p(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun xp(context: Context): Int = p(context).getInt(XP, 0)
    fun hours(context: Context): Double = p(context).getFloat(HOURS, 0f).toDouble()
    fun streak(context: Context): Int = p(context).getInt(STREAK, 0)
    fun mission(context: Context): String = p(context).getString(MISSION, "Biology — 45 min") ?: "Biology — 45 min"

    fun level(context: Context): Int = 1 + (xp(context) / 500)

    fun addXp(context: Context, amount: Int) {
        p(context).edit().putInt(XP, xp(context) + amount).apply()
    }

    fun addMinutes(context: Context, minutes: Int) {
        val newHours = hours(context) + minutes / 60.0
        p(context).edit().putFloat(HOURS, newHours.toFloat()).apply()
        touchStreak(context)
    }

    fun setMission(context: Context, value: String) {
        p(context).edit().putString(MISSION, value).apply()
    }

    private fun touchStreak(context: Context) {
        val today = LocalDate.now().toString()
        val old = p(context).getString(ACTIVE_DATE, null)
        if (old != today) {
            p(context).edit()
                .putString(ACTIVE_DATE, today)
                .putInt(STREAK, streak(context) + 1)
                .apply()
        }
    }
}
