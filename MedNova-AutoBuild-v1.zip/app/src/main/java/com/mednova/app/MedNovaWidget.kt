package com.mednova.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.math.roundToInt

class MedNovaWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.mednova_widget)
            val hours = MedNovaStore.hours(context)
            views.setTextViewText(
                R.id.widget_stats,
                "🔥 ${MedNovaStore.streak(context)} days   ⭐ ${MedNovaStore.xp(context)} XP\n" +
                    "🏆 Level ${MedNovaStore.level(context)}   ⏱ ${String.format("%.1f", hours)} / 13 h"
            )
            views.setTextViewText(R.id.widget_mission, "🎯 ${MedNovaStore.mission(context)}")

            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, 100, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_title, pending)
            views.setOnClickPendingIntent(R.id.widget_stats, pending)
            views.setOnClickPendingIntent(R.id.widget_mission, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
