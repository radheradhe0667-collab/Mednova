package com.mednova.app

import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }
        webView.webViewClient = WebViewClient()

        webView.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun getStats(): String {
                val json = JSONObject()
                json.put("xp", MedNovaStore.xp(this@MainActivity))
                json.put("level", MedNovaStore.level(this@MainActivity))
                json.put("hours", MedNovaStore.hours(this@MainActivity))
                json.put("streak", MedNovaStore.streak(this@MainActivity))
                json.put("mission", MedNovaStore.mission(this@MainActivity))
                return json.toString()
            }

            @android.webkit.JavascriptInterface
            fun addStudy(minutes: Int) {
                if (minutes > 0 && minutes <= 1440) {
                    MedNovaStore.addMinutes(this@MainActivity, minutes)
                    MedNovaStore.addXp(this@MainActivity, minutes * 2)
                    refreshWidget()
                    runOnUiThread { webView.evaluateJavascript("window.mednovaRefresh && window.mednovaRefresh()", null) }
                }
            }

            @android.webkit.JavascriptInterface
            fun setMission(value: String) {
                if (value.length <= 120) {
                    MedNovaStore.setMission(this@MainActivity, value)
                    refreshWidget()
                }
            }
        }, "MedNova")

        webView.loadUrl("file:///android_asset/web/index.html")
    }

    private fun refreshWidget() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, MedNovaWidget::class.java))
        ids.forEach { MedNovaWidget.update(this, manager, it) }
    }
}
