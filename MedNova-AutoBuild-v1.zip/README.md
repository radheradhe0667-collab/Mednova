# MedNova

A clean Android-first NEET study productivity app foundation.

Included now:
- WebView-based MedNova dashboard
- Persistent XP, level, study hours, streak, and mission data
- Real Android home-screen widget
- Widget synchronization
- Focus-session button
- Offline-first architecture
- No network permission required

Next planned modules:
- subject/chapter database
- DPP/question tracking
- accuracy analytics
- backlog
- revision system
- ADHD Focus/Rescue modes
- notifications
- configurable NEET countdown
- richer widget actions

Build:
Open the project in Android Studio with an Android SDK installed, then run `assembleDebug`.
